# BlogSphere – Advanced Backend Development

A portfolio-ready REST API built with **Node.js, Express.js and MongoDB**. It covers user registration/login, JWT authentication, password hashing, blog CRUD, search, pagination, likes, role-based admin analytics, validation and security middleware.

## Features

- User registration and login with bcrypt password hashing
- JWT-protected routes and role-based admin authorization
- User profile view and update
- Create, read, update and delete blogs
- Draft/published blog status
- Search, category filtering and pagination
- Blog view counter and like/unlike endpoint
- Admin analytics endpoint
- Request validation, Helmet security headers, CORS and rate limiting
- Centralized error handling and simple API documentation page

## Requirements

- Node.js 18 or later
- npm
- MongoDB local installation or MongoDB Atlas account
- Postman (recommended for API testing)

## Run locally

1. Extract this ZIP.
2. Open the extracted `BlogSphere-Advanced-Backend` folder in VS Code.
3. Open the VS Code terminal in that folder.
4. Install dependencies:

   ```bash
   npm install
   ```

5. Copy `.env.example` to a new file named `.env`.
6. Set `MONGO_URI` to your MongoDB connection string and replace `JWT_SECRET` with a long random secret.
7. Start the development server:

   ```bash
   npm run dev
   ```

8. Visit `http://localhost:5000`, `http://localhost:5000/api/health`, or `http://localhost:5000/api/docs`.

> Never upload `.env` or real credentials to GitHub. `.gitignore` already excludes it.

## API reference

Base URL: `http://localhost:5000/api`

| Method | Endpoint | Auth | Description |
|---|---|---:|---|
| POST | `/auth/register` | No | Register account |
| POST | `/auth/login` | No | Login and receive JWT |
| GET | `/users/me` | Yes | Get current profile |
| PATCH | `/users/me` | Yes | Update profile name |
| GET | `/blogs` | No | List published blogs |
| GET | `/blogs/:id` | No | Read a published blog (increments views) |
| POST | `/blogs` | Yes | Create a blog |
| PATCH | `/blogs/:id` | Yes | Update your own blog |
| DELETE | `/blogs/:id` | Yes | Delete your own blog |
| POST | `/blogs/:id/like` | Yes | Like/unlike a published blog |
| GET | `/admin/analytics` | Admin | Platform statistics |

Protected endpoints require this header:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

### Register

`POST /api/auth/register`

```json
{
  "name": "Demo User",
  "email": "demo@example.com",
  "password": "DemoPass123"
}
```

### Login

`POST /api/auth/login`

```json
{
  "email": "demo@example.com",
  "password": "DemoPass123"
}
```

Copy the `token` from the response and use it as the Bearer token for protected endpoints.

### Create a blog

`POST /api/blogs`

```json
{
  "title": "Getting Started with Node.js",
  "content": "Node.js lets developers run JavaScript on the server. This is a sample article body.",
  "category": "Technology",
  "tags": ["nodejs", "backend"],
  "status": "published"
}
```

### Search and pagination

`GET /api/blogs?search=node&category=Technology&page=1&limit=10`

## Make a user an admin (local development)

For a demo, register your account first. In MongoDB Compass, open the `users` collection in the `blogsphere` database and change only your own user's `role` field from `user` to `admin`. Do not expose a public endpoint that lets users assign themselves admin access.

## Suggested screenshots for submission

1. Server running successfully in VS Code terminal.
2. Successful registration response in Postman.
3. Successful login response showing token (hide the token in public screenshots).
4. Create blog response.
5. Published blogs list response.
6. Admin analytics response after assigning your own test account the admin role.

## GitHub upload

Create a repository named `BlogSphere-Advanced-Backend`. Upload the extracted project folder contents. Ensure `.env` is not uploaded. Add the screenshots to a `screenshots/` folder if you capture them.

## Important scope note

This is a learning/portfolio starter, not a production-certified service. Before production deployment, add refresh-token rotation and revocation, email verification and password reset, automated tests, audit logging, stricter CORS configuration, monitoring, backups and deployment secrets management.
