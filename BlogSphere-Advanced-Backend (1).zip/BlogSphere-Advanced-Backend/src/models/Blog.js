const mongoose = require("mongoose");

const blogSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, minlength: 3, maxlength: 150 },
  content: { type: String, required: true, minlength: 10 },
  category: { type: String, required: true, trim: true, maxlength: 50 },
  tags: [{ type: String, trim: true, maxlength: 30 }],
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  status: { type: String, enum: ["draft", "published"], default: "draft" },
  views: { type: Number, default: 0 },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }]
}, { timestamps: true });

blogSchema.index({ title: "text", content: "text", category: "text" });
module.exports = mongoose.model("Blog", blogSchema);
