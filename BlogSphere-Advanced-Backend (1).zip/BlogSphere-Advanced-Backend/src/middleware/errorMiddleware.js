function notFound(req, res, next) {
  res.status(404);
  next(new Error(`Route not found: ${req.method} ${req.originalUrl}`));
}

function errorHandler(err, req, res, next) {
  const status = res.statusCode && res.statusCode !== 200 ? res.statusCode : (err.status || 500);
  res.status(status).json({
    success: false,
    message: err.code === 11000 ? "An account with this email already exists." : err.message || "Internal server error"
  });
}

module.exports = { notFound, errorHandler };
