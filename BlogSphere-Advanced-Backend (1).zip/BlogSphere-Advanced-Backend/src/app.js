const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");
const blogRoutes = require("./routes/blogRoutes");
const adminRoutes = require("./routes/adminRoutes");
const { notFound, errorHandler } = require("./middleware/errorMiddleware");

const app = express();

app.use(helmet());
app.use(cors({
  origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(",") : true,
  credentials: true
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: true, limit: "20kb" }));
if (process.env.NODE_ENV !== "test") app.use(morgan("dev"));

app.use("/api", rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 200,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { success: false, message: "Too many requests. Please try again later." }
}));

app.get("/", (req, res) => res.json({
  success: true,
  name: "BlogSphere API",
  version: "1.0.0",
  documentation: "/api/docs",
  health: "/api/health"
}));

app.get("/api/health", (req, res) => res.json({
  success: true,
  status: "healthy",
  timestamp: new Date().toISOString()
}));

app.get("/api/docs", (req, res) => {
  res.type("html").send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BlogSphere API</title><style>body{font:16px system-ui;max-width:900px;margin:40px auto;padding:0 20px;color:#172033}code{background:#eef2ff;padding:3px 6px;border-radius:5px}.route{padding:12px;border-bottom:1px solid #ddd}h1{color:#2344a0}</style></head><body><h1>BlogSphere API Documentation</h1><p>Base URL: <code>http://localhost:${process.env.PORT || 5000}/api</code></p><h2>Authentication</h2><div class="route">POST <code>/auth/register</code> — Create an account</div><div class="route">POST <code>/auth/login</code> — Login and receive JWT</div><h2>Users</h2><div class="route">GET <code>/users/me</code> — Current user (Bearer token)</div><div class="route">PATCH <code>/users/me</code> — Update name (Bearer token)</div><h2>Blogs</h2><div class="route">GET <code>/blogs</code> — Published blogs; supports <code>?search=&category=&page=1&limit=10</code></div><div class="route">GET <code>/blogs/:id</code> — Get one published blog</div><div class="route">POST <code>/blogs</code> — Create blog (Bearer token)</div><div class="route">PATCH <code>/blogs/:id</code> — Update own blog (Bearer token)</div><div class="route">DELETE <code>/blogs/:id</code> — Delete own blog (Bearer token)</div><div class="route">POST <code>/blogs/:id/like</code> — Toggle like (Bearer token)</div><h2>Admin</h2><div class="route">GET <code>/admin/analytics</code> — Platform statistics (admin token)</div><p>Send JSON with <code>Content-Type: application/json</code>. Protected endpoints require <code>Authorization: Bearer YOUR_TOKEN</code>.</p></body></html>`);
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/blogs", blogRoutes);
app.use("/api/admin", adminRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
