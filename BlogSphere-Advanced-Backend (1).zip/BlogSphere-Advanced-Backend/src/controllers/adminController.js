const User = require("../models/User");
const Blog = require("../models/Blog");

async function analytics(req, res, next) {
  try {
    const [users, blogs, published, drafts, views] = await Promise.all([
      User.countDocuments(),
      Blog.countDocuments(),
      Blog.countDocuments({ status: "published" }),
      Blog.countDocuments({ status: "draft" }),
      Blog.aggregate([{ $group: { _id: null, total: { $sum: "$views" } } }])
    ]);
    res.json({
      success: true,
      data: { totalUsers: users, totalBlogs: blogs, publishedBlogs: published, draftBlogs: drafts, totalViews: views[0]?.total || 0 }
    });
  } catch (error) { next(error); }
}

module.exports = { analytics };
