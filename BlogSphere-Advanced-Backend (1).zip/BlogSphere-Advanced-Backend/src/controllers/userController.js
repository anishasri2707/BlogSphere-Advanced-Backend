const User = require("../models/User");

async function getMe(req, res, next) {
  try {
    res.json({ success: true, user: req.user });
  } catch (error) { next(error); }
}

async function updateMe(req, res, next) {
  try {
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { name: req.body.name },
      { new: true, runValidators: true, select: "_id name email role" }
    );
    res.json({ success: true, message: "Profile updated.", user });
  } catch (error) { next(error); }
}

module.exports = { getMe, updateMe };
