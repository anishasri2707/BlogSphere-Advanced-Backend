const mongoose = require("mongoose");
const Blog = require("../models/Blog");

function validId(id) { return mongoose.isValidObjectId(id); }

async function createBlog(req, res, next) {
  try {
    const blog = await Blog.create({
      title: req.body.title,
      content: req.body.content,
      category: req.body.category,
      tags: req.body.tags || [],
      status: req.body.status || "draft",
      author: req.user._id
    });
    await blog.populate("author", "name");
    res.status(201).json({ success: true, message: "Blog created.", data: blog });
  } catch (error) { next(error); }
}

async function getBlogs(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));
    const filter = { status: "published" };
    if (req.query.category) filter.category = req.query.category;
    if (req.query.search) {
      const safeSearch = req.query.search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").slice(0, 80);
      filter.title = { $regex: safeSearch, $options: "i" };
    }
    const [blogs, total] = await Promise.all([
      Blog.find(filter).populate("author", "name").sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
      Blog.countDocuments(filter)
    ]);
    res.json({ success: true, page, limit, total, totalPages: Math.ceil(total / limit), data: blogs });
  } catch (error) { next(error); }
}

async function getBlog(req, res, next) {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid blog ID." });
    const blog = await Blog.findOneAndUpdate(
      { _id: req.params.id, status: "published" },
      { $inc: { views: 1 } },
      { new: true }
    ).populate("author", "name");
    if (!blog) return res.status(404).json({ success: false, message: "Published blog not found." });
    res.json({ success: true, data: blog });
  } catch (error) { next(error); }
}

async function updateBlog(req, res, next) {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid blog ID." });
    const allowed = ["title", "content", "category", "tags", "status"];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];
    const blog = await Blog.findOneAndUpdate(
      { _id: req.params.id, author: req.user._id },
      { $set: updates },
      { new: true, runValidators: true }
    ).populate("author", "name");
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found or you are not its owner." });
    res.json({ success: true, message: "Blog updated.", data: blog });
  } catch (error) { next(error); }
}

async function deleteBlog(req, res, next) {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid blog ID." });
    const blog = await Blog.findOneAndDelete({ _id: req.params.id, author: req.user._id });
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found or you are not its owner." });
    res.json({ success: true, message: "Blog deleted." });
  } catch (error) { next(error); }
}

async function toggleLike(req, res, next) {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid blog ID." });
    const blog = await Blog.findOne({ _id: req.params.id, status: "published" });
    if (!blog) return res.status(404).json({ success: false, message: "Published blog not found." });
    const alreadyLiked = blog.likes.some(id => id.equals(req.user._id));
    if (alreadyLiked) blog.likes.pull(req.user._id);
    else blog.likes.addToSet(req.user._id);
    await blog.save();
    res.json({ success: true, liked: !alreadyLiked, likesCount: blog.likes.length });
  } catch (error) { next(error); }
}

module.exports = { createBlog, getBlogs, getBlog, updateBlog, deleteBlog, toggleLike };
