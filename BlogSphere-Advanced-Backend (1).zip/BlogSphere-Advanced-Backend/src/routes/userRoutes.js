const router = require("express").Router();
const { body } = require("express-validator");
const validate = require("../middleware/validate");
const { protect } = require("../middleware/authMiddleware");
const { getMe, updateMe } = require("../controllers/userController");

router.use(protect);
router.get("/me", getMe);
router.patch("/me", [body("name").trim().isLength({ min: 2, max: 60 })], validate, updateMe);

module.exports = router;
