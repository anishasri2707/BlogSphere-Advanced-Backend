const router = require("express").Router();
const { body } = require("express-validator");
const validate = require("../middleware/validate");
const { protect } = require("../middleware/authMiddleware");
const controller = require("../controllers/blogController");

router.get("/", controller.getBlogs);
router.get("/:id", controller.getBlog);
router.post("/", protect, [
  body("title").trim().isLength({ min: 3, max: 150 }),
  body("content").isLength({ min: 10 }),
  body("category").trim().isLength({ min: 2, max: 50 }),
  body("status").optional().isIn(["draft", "published"]),
  body("tags").optional().isArray({ max: 10 })
], validate, controller.createBlog);
router.patch("/:id", protect, [
  body("title").optional().trim().isLength({ min: 3, max: 150 }),
  body("content").optional().isLength({ min: 10 }),
  body("category").optional().trim().isLength({ min: 2, max: 50 }),
  body("status").optional().isIn(["draft", "published"]),
  body("tags").optional().isArray({ max: 10 })
], validate, controller.updateBlog);
router.delete("/:id", protect, controller.deleteBlog);
router.post("/:id/like", protect, controller.toggleLike);

module.exports = router;
