const router = require("express").Router();
const { protect, adminOnly } = require("../middleware/authMiddleware");
const { analytics } = require("../controllers/adminController");

router.get("/analytics", protect, adminOnly, analytics);
module.exports = router;
